package aeroportoSys;

import java.util.ArrayList;

public class Compania {
		
		private String nomeCompania;
		ArrayList<Voos> listaVoos = new ArrayList<>();
		private int qtdVoos;
		
		
		public String getNomeCompania() {
			return nomeCompania;
		}
		
		public void setNomeCompania(String nomeCompania) {
			this.nomeCompania = nomeCompania;
		}

		public int getQtdVoos() {
			return qtdVoos;
		}

		public void setQtdVoos(int qtdVoos) {
			this.qtdVoos = qtdVoos;
		}

	

	
}
