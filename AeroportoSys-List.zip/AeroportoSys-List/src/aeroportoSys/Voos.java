package aeroportoSys;

import java.util.ArrayList;

public class Voos {

	private String numVoo;
	ArrayList<Passageiros> passageirosLista = new ArrayList<>(10);
	public int qtdAssentos = 20;
	
	public String getNumVoo() {
		return numVoo;
	}

	public void setNumVoo(String num) {
		this.numVoo = num;
	}






}
