package aeroportoSys;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;

public class Sistema {
		
		private BufferedReader reader;
		private Compania c;
		
		public static void main(String[] args) throws Exception{
			Sistema se = new Sistema();
			se.c = new Compania();
			se.reader = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Informe o nome da Compania:");
			String nomeCompania = se.reader.readLine();
			se.c.setNomeCompania(nomeCompania);
			se.menu();
		}

		public void menu() throws Exception{
			String opcao = "";
			while(!opcao.equals("6")){
				System.out.println("-------------------------");
				System.out.println("Escolha uma das opções abaixo:");
				System.out.println("[1] Cadastrar Voo.");
				System.out.println("[2] Lista Voos.");
				System.out.println("[3] Cadastrar passageiros.");
				System.out.println("[4] Lista passageiros por voo.");
				System.out.println("[5] Lista de assentos livres por voo");
				System.out.println("[6] Sair...");
				System.out.println("-------------------------------------");
				opcao = this.reader.readLine();
				
				if(opcao.equals("1")){
					this.cadastrarVoos();
				}else if(opcao.equals("2")) {
					this.listarVoos();
				}else if(opcao.equals("3")) {
					this.cadastrarPassageiros();
				}else if(opcao.equals("4")) {
					this.listaPassageirosVoo();
				}else if(opcao.equals("5")) {
					this.assentosLivres();
				}else if(opcao.equals("6")) {	
					System.out.println("Encerrando...");
					System.exit(0);
				}else {
					System.out.println("Opcao invalida...");
				}
			}
		}
		

		public void cadastrarVoos() throws NumberFormatException, IOException{
			System.out.println("-----------------------------");
			System.out.println("CADASTRO DE VOOS");
			System.out.println("-----------------------------");
			int e = 1;
			for (int i = 0; i < 10; i++) {
				Voos v = new Voos();
				System.out.println("-------------------------");
				System.out.println("Digite o numero do voo " + e + " ou pressione apenas ENTER para voltar ao menu inicial:");
				String voo = this.reader.readLine();
				if(voo.equals("")) {
					System.out.println("Cadastro encerrado. Retornando ao menu inicial...");
					break;
				}
				v.setNumVoo(voo);
				this.c.listaVoos.add(v);
				this.c.setQtdVoos(e);
				e++;
			}	
		}
			
		
		public void listarVoos() throws NumberFormatException, IOException{
			System.out.println("---------------------------");
			System.out.println("LISTA DE VOOS:");
			System.out.println("-----------------------------");
			System.out.println("Quantidade de voos cadastrados: " + this.c.getQtdVoos() + ".");
			Iterator <Voos> it = this.c.listaVoos.iterator();
			while(it.hasNext()){
				Voos v1 = it.next();
				System.out.println("Voo " +  v1.getNumVoo() + ";");
			}
		}
		
		
		public void cadastrarPassageiros() throws IOException {
			System.out.println("-----------------------------");
			System.out.println("CADASTRO DE PASSAGEIROS");
			System.out.println("-----------------------------");
			for(int i = 0; i < this.c.getQtdVoos(); i++) {
				System.out.println("Digite o número do VOO ou pressione apenas ENTER para voltar ao menu inicial:");
				String numVoo = this.reader.readLine();
				String voo = this.c.listaVoos.get(i).getNumVoo();
				if(numVoo.equals("")) {
					System.out.println("Cadastro encerrado. Retornando ao menu inicial...");
					break;
				}else
				if(numVoo.equals(voo)) {
						int l = 1;
						for(int j = 0; j < 10 ; j++) {
							System.out.println("Informe o nome do passageiro" + l + ":");
							String nomePassageiro = this.reader.readLine();
							if(nomePassageiro.equals("")) {
								System.out.println("Cadastro encerrado. Retornando ao menu inicial...");
								break;
							}
							
							Passageiros p1 = new Passageiros();
							p1.setNome(nomePassageiro);
							this.c.listaVoos.get(i).passageirosLista.add(p1);
							l++;
						}
					break;
					}
				}

			}	

		
		public void listaPassageirosVoo() throws IOException {
			System.out.println("-----------------------------");
			System.out.println("LISTA DE PASSAGEIROS POR VOO");
			System.out.println("-----------------------------");
			int e = 1;
			for(int i = 0; i < this.c.listaVoos.size(); i++) {
				System.out.println("_______________________________");
				System.out.println("Digite o numero do voo " + e + " ou pressione apenas ENTER para voltar ao menu inicial:");
				String nVoo = this.reader.readLine();
				if(nVoo.equals("")) {
					System.out.println("Busca encerrada. Retornando ao menu inicial...");
					break;
				}
				String v2 = this.c.listaVoos.get(i).getNumVoo();
				if(nVoo.equals(v2)) {
					Iterator <Passageiros> lista = this.c.listaVoos.get(i).passageirosLista.iterator();
					System.out.println("Lista:");
					while(lista.hasNext()){
						Passageiros p = lista.next();
						System.out.println("Passageiro :" + p.getNome() + ";");
					}
						
				}
				e++;
			}
					
		}
			
	
		
		public void assentosLivres() throws IOException {
			System.out.println("---------------------------------");
			System.out.println("LISTA DE ASSENTOS LIVRES POR VOO");
			System.out.println("---------------------------------");
			for(int i = 0; i < this.c.listaVoos.size(); i++) {
				System.out.println("_______________________________");
				System.out.println("Digite o numero do voo desejado ou pressione apenas ENTER para voltar ao menu inicial:");
				String nVoo = this.reader.readLine();
				if(nVoo.equals("")) {
					System.out.println("Busca encerrada. Retornando ao menu inicial...");
					break;
				}
				String v2 = this.c.listaVoos.get(i).getNumVoo();
				if(nVoo.equals(v2)) {
					int assentosOcupados = this.c.listaVoos.get(i).passageirosLista.size();
					System.out.println(assentosOcupados);
					Voos v = new Voos();
					int assentosLivres =  v.qtdAssentos - assentosOcupados;
					System.out.println("Existem " + assentosLivres + " assentos livres neste voo.");
				}else {
					System.out.println("Voo não encontrado...!");
				}
				
			}
		}
		
} //fim classe
		
		





